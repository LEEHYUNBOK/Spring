package net.skhu;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class P201732028ApplicationTests {

	@Test
	void contextLoads() {
	}

}

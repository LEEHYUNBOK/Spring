package net.skhu;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class V201732028Application {

	public static void main(String[] args) {
		SpringApplication.run(V201732028Application.class, args);
	}

}

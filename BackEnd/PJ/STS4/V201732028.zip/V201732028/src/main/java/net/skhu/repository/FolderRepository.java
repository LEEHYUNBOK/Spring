package net.skhu.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import net.skhu.entity.Folder;

public interface FolderRepository  extends JpaRepository<Folder, Integer> {

}
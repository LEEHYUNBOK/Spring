package net.skhu;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class V201732028ApplicationTests {

	@Test
	void contextLoads() {
	}

}

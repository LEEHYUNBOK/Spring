package net.skhu;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class F201732028Application {

	public static void main(String[] args) {
		SpringApplication.run(F201732028Application.class, args);
	}

}
